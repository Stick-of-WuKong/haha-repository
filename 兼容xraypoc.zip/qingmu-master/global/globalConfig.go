package global

var (
	IsShowPath     bool // 是否显示请求方法以及路径
	IsShowRequest  bool // 是否显示请求数据
	IsShowResponse bool // 是否响应数据
)

var (
	CeyeApi    string //ceye.io api
	CeyeDomain string // domain
)

var Proxy string // fasthttp代理
